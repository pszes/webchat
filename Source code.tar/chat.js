const buttonElement = document.getElementById("submitmsg");
        var mySocket=new WebSocket("http://localhost:8080/Chat/Chat");

        mySocket.onopen = () => {
            console.log('open connection')
        }

        mySocket.onclose = () => {
            console.log('close connection')
        }

        mySocket.onmessage = event => {
            var acceptmessage = event.data.split(' ');
            var textmessage = "";
            if(acceptmessage[0]!=[""]){
            for (var i = 1; i < acceptmessage.length; i++) {
                textmessage = textmessage + acceptmessage[i];
            }
            var t = document.getElementById("table");
            t.insertAdjacentHTML("afterend","<tr><td style=\"text-align: left; width: 120px;\">"+acceptmessage[0]+"</td><td style=\"text-align: left;\"><span>"+textmessage+"</span></td></tr>");
            } 
        }

        buttonElement.addEventListener("click", function (event) {
            var name = document.getElementById("name").value;
            var text = document.getElementById("text").value;
            var sendmessage = document.getElementById("name").value.replaceAll(/\s/g,'')+" "+document.getElementById("text").value;
            if(text){
                mySocket.send(sendmessage);
            }
        });