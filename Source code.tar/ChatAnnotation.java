package websocket.chat;

import java.io.*;
import java.util.*;
import javax.websocket.*;
import java.util.concurrent.*;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint(value="/Chat")

public class ChatAnnotation {

    private static final Set<ChatAnnotation> connections = new CopyOnWriteArraySet<>();

    private Session session;

    private Queue<String> messageBacklog = new ArrayDeque<>();
    private boolean messageInProgress = false;

    @OnOpen
    public void start(Session session) {
        this.session = session;
        connections.add(this);
        System.out.println("連接成功");
    }


    @OnClose
    public void end() {
        connections.remove(this);
        System.out.println("連接結束");
    }


    @OnMessage
    public void incoming(String message) {
        for (ChatAnnotation client : connections){
            try{
                client.sendMessage(message);
            } catch(IOException e){}
        }
    }


    @OnError
    public void onError(Throwable t) throws Throwable {
        System.out.println("連接失敗");
    }

    private void sendMessage(String msg) throws IOException {

        synchronized (this) {
            if (messageInProgress) {
                messageBacklog.add(msg);
                return;
            } else {
                messageInProgress = true;
            }
        }

        boolean queueHasMessagesToBeSent = true;

        String messageToSend = msg;
        do {
            session.getBasicRemote().sendText(messageToSend);
            synchronized (this) {
                messageToSend = messageBacklog.poll();
                if (messageToSend == null) {
                    messageInProgress = false;
                    queueHasMessagesToBeSent = false;
                }
            }

        } while (queueHasMessagesToBeSent);
     }


}
